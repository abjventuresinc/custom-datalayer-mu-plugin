<p>
	<input type="checkbox" name="_wc_prf_no_feed" {excluded_checked} id="_wc_prf_no_feed">
	<label for="_wc_prf_no_feed"><?php esc_html_e( 'Exclude from feed', 'woocommerce_gpf' ); ?></label>
</p>
<p>
	<input type="checkbox" name="_wc_prf_anonymised" {anonymised_checked} id="_wc_prf_anonymised">
	<label for="_wc_prf_anonymised"><?php esc_html_e( 'Anonymise reviewer in feed', 'woocommerce_gpf' ); ?></label>
</p>
<p>
	<label for="_wc_prf_incentivized"><?php esc_html_e( 'Review was incentivized', 'woocommerce_gpf' ); ?>:</label><br>
	<select name="_wc_prf_incentivized" id="_wc_prf_incentivized">
		<option value=""><?php esc_html_e( 'Use default value', 'woocommerce_gpf' ); ?></option>
		<option value="1" {1_selected}><?php esc_html_e( 'Review was incentivized', 'woocommerce_gpf' ); ?></option>
		<option value="0" {0_selected}><?php esc_html_e( 'Review was not incentivized', 'woocommerce_gpf' ); ?></option>
	</select>
</p>
