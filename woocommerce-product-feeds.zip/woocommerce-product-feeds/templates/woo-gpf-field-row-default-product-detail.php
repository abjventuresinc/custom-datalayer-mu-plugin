	<label for="_woocommerce_gpf_data[{key}][{subidx}][section_name]"><?php esc_html_e( 'Section name:', 'woocommerce_gpf' ); ?></label>
	<br>
	<input type="text" name="_woocommerce_gpf_data[{key}][{subidx}][section_name]" value="{section_name}">
	<br>
	<label for="_woocommerce_gpf_data[{key}][{subidx}][attribute_name]"><?php esc_html_e( 'Attribute name:', 'woocommerce_gpf' ); ?></label>
	<br>
	<input type="text" name="_woocommerce_gpf_data[{key}][{subidx}][attribute_name]" value="{attribute_name}">
	<br>
	<label for="_woocommerce_gpf_data[{key}][{subidx}][attribute_value]"><?php esc_html_e( 'Attribute value:', 'woocommerce_gpf' ); ?></label>
	<br>
	<textarea name="_woocommerce_gpf_data[{key}][{subidx}][attribute_value]" cols="80" rows="3">{attribute_value}</textarea>
	<br>
