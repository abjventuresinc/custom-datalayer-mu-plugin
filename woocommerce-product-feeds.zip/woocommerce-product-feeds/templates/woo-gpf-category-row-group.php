<?php // phpcs:disable Internal.NoCodeFound ?>
<div class="form-field gpf-group-heading">
	<p class="gpf-group-heading">{group_name}</p>
</div>
