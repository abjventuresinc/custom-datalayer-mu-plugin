<?php // phpcs:disable Internal.NoCodeFound ?>
<tr class="gpf-group-heading">
	<th>
		<p class="gpf-group-heading">{group_name}</p>
	</th>
	<td></td>
</tr>
