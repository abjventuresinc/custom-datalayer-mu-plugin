<h3 class="gpf-field-heading"><?php esc_html_e( 'Fields to enable', 'woocommerce_gpf' ); ?></h3>
<p><?php esc_html_e( 'Choose which fields you want in your feed for each product, and set store-wide defaults below where necessary: ', 'woocommerce_gpf' ); ?><br/></p>
<table class="form-table gpf-settings-form">
