<?php // phpcs:disable Internal.NoCodeFound ?>
<option value="{key}"{disabled}{selected}>{value}</option>
