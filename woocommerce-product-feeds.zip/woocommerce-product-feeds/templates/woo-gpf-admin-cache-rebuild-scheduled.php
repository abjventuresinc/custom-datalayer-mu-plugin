<?php // phpcs:disable Internal.NoCodeFound ?><h4 class="woocommerce_gpf_cache_rebuild_notice">{msg}</h4>
