<div class="notice notice-success">
	<p><?php esc_html_e( 'Feed deleted', 'woocommerce_gpf' ); ?></p>
</div>
