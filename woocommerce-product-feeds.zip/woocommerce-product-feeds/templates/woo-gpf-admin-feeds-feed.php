<?php // phpcs:disable Internal.NoCodeFound ?>
<li>{html_name} : <a target="_blank" rel="noopener noreferrer" href="{attr_url}">{html_url}</a>
</li>
