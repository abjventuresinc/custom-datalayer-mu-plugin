<?php // phpcs:disable Internal.NoCodeFound ?>
<input name="_woocommerce_gpf_data[{key}]" class="woocommerce_gpf_product_type_{raw_key} woocommerce-gpf-store-default" value="{current_data}" style="width: 100%; max-width: 750px;"{placeholder}>
