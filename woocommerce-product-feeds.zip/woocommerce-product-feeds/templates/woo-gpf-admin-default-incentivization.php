<?php
/**
 * Template for default_incentivization setting for Google Review feed.
 *
 * @package  woocommerce-gpf
 */

?>
<p>
	<label for="woocommerce_gpf_config[shop_code]"><strong><?php esc_html_e( 'Default incentivization value for reviews in review feed:', 'woocommerce_gpf' ); ?></strong></label>
</p>
<p>
	<select name="woocommerce_gpf_config[default_incentivization]" id="woocommerce_gpf_config[default_incentivization]">
		<option value=""><?php esc_html_e( 'Not incentivized', 'woocommerce_gpf' ); ?></option>
		<option value="1" {1_selected}><?php esc_html_e( 'Incentivized', 'woocommerce_gpf' ); ?></option>
	</select>
</p>
