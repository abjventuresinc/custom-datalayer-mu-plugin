</p>
<p class="description">
	<?php echo esc_html(
		__(
			'Note: Since you have an active promotions feed, any promotions which affect specific categories will automatically have their promotion IDs added to any you manually specify here.',
			'woocommerce_gpf'
		)
	); ?>
