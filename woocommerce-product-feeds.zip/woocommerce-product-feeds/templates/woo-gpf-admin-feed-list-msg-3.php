<div class="notice notice-success">
	<p><?php esc_html_e( 'Feed created', 'woocommerce_gpf' ); ?></p>
</div>
