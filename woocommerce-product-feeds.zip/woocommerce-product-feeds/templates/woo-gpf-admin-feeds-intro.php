<h3><?php esc_html_e( 'Active feeds', 'woocommerce_gpf' ); ?></h3>
<ul>

