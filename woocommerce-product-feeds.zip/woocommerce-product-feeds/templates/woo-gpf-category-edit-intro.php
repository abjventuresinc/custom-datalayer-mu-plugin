<tr>
	<th colspan="2">
		<h3><?php esc_html_e( 'Product Feed Information', 'woocommerce_gpf' ); ?></h3>
		<span style="font-weight: normal;"><?php
		esc_html_e(
			'Only enter values here if you want to override the store defaults for products in this category. You can still override the values here against individual products if you want to.',
			'woocommerce_gpf'
		);
		?></span>
	</th>
</tr>
