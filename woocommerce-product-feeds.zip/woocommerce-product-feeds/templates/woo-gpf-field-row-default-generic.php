<?php // phpcs:disable Internal.NoCodeFound ?><input type="text" name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default" value="{defaultvalue}" {placeholder}>
