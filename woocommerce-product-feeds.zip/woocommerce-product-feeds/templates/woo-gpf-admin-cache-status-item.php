<?php // phpcs:disable Internal.NoCodeFound ?>
<li>{name}
	<ul class="ul-disc"><li>{status}</li></ul>
</li>
