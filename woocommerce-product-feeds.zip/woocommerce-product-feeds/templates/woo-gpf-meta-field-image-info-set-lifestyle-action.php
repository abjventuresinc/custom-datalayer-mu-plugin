<?php // phpcs:disable Internal.NoCodeFound ?>
<div class="woo-gpf-image-item-status woo-gpf-image-item-lifestyle">
	<a class="woo-gpf-image-source-set-lifestyle-item" data-nonce="{nonce}">
		<span class="dashicons dashicons-admin-post"></span> <?php echo esc_html( _x( 'Mark as lifestyle image', 'Button to set a specific image as the lifestyle image for a product in the feed', 'woocommerce_gpf' ) ); ?>
	</a>
</div>


