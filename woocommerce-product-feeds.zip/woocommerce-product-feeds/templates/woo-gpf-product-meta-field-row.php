<?php // phpcs:disable Internal.NoCodeFound ?>
<p class="woocommerce-gpf-meta-field-row"><label for="_woocommerce_gpf_data[{key}]">{field_description}{field_defaults}</label></p>
<p>{field_input}</p>
