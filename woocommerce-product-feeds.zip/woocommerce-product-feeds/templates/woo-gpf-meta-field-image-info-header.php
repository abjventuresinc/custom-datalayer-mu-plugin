<div class="woocommerce-gpf-meta-field-row ">
	<p>
		<strong><?php esc_html_e( 'Images', 'woocommerce_gpf' ); ?></strong>
	</p>
	<p>
		<?php esc_html_e( 'For simple products, the first image (below) will be used as the primary image unless a primary image is specifically chosen. For variable products, the primary image will be the variation image if available.', 'woocommerce_gpf' ); ?>
	</p>

	<div class="woo-gpf-image-source-list-container woo-gpf-image-source-list-container-collapsed">
