<?php // phpcs:disable Internal.NoCodeFound ?>
<tr>
	<td data-export-label="{attr_name}">{name}</td>
	<td class="help">&nbsp;</td>
	<td>{status}</td>
</tr>
