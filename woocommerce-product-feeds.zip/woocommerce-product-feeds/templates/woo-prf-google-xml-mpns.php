<?php // phpcs:disable Internal.NoCodeFound ?>
<mpns>{mpns}</mpns>
