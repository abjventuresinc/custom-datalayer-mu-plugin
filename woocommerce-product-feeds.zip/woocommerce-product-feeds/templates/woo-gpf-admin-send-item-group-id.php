<p style="margin-left: 2em;">
	<input type="checkbox" class="woocommerce_gpf_field_selector" name="woocommerce_gpf_config[send_item_group_id]" id="woocommerce_gpf_config[send_item_group_id]" {send_item_group_id_selected}>
	<label for="woocommerce_gpf_config[send_item_group_id]"><?php
	echo esc_html( __( 'Send &ldquo;item_group_id&rdquo; in Google feed for variable products', 'woocommerce_gpf' ) );
	?></label>
</p>
