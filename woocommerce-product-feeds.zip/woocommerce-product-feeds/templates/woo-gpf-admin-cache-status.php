<div class="woocommerce_gpf_intro_cache_status">
	<h3><?php esc_html_e( 'Feed status', 'woocommerce_gpf' ); ?></h3>
	{msg}
	<hr>
	<ul class="ul-disc">
		{status_items}
	</ul>
	<p style="vertical-align: center; text-align: center;">
		<a href="{settings_url}" class="button button-primary">Refresh stats &raquo;</a>&nbsp;&nbsp;
		<small><a href="{rebuild_url}" >Rebuild feed &raquo;</a></small>
	</p>
</div>
