<div class="woo-gpf-image-item-status woo-gpf-image-item-primary">
	<a class="woo-gpf-image-source-set-primary-item" data-nonce="{nonce}">
		<span class="dashicons dashicons-star-empty"></span> <?php echo esc_html( _x( 'Make primary', 'Button to set a specific image as the primary image for a product in the feed', 'woocommerce_gpf' ) ); ?>
	</a>
</div>


