<?php // phpcs:disable Internal.NoCodeFound ?>
<option value="{value}" {selected}>{description}</option>
