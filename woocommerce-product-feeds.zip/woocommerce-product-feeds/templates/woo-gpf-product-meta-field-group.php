<?php // phpcs:disable Internal.NoCodeFound ?>
<p class="woocommerce-gpf-meta-field-row gpf-group-heading">{group_name}</p>
