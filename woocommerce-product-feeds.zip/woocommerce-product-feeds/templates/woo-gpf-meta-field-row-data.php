<?php // phpcs:disable Internal.NoCodeFound ?>
<td class="forminp">
	<div class="woocommerce_gpf_field_selector_group">
		{defaults}
	</div>
</td>
