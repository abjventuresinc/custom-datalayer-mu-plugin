	<label for="_woocommerce_gpf_data[{key}][0][months]"><?php esc_html_e( 'Number of monthly instalments:', 'woocommerce_gpf' ); ?></label><br>
	<input type="text" name="_woocommerce_gpf_data[{key}][0][months]" class="woocommerce-gpf-store-default" size="3" value="{defaultvaluemonths}" {placeholder}>
</p>
<p>
	<label for="_woocommerce_gpf_data[{key}][0][amount]"><?php esc_html_e( 'Amount of each payment, including 3-digit currency code, e.g. "50 USD":', 'woocommerce_gpf' ); ?></label><br>
	<input type="text" name="_woocommerce_gpf_data[{key}][0][amount]" class="woocommerce-gpf-store-default"  size="10" value="{defaultvalueamount}" {placeholder}>
