<?php // phpcs:disable Internal.NoCodeFound ?>
<div class="woocommerce-gpf-element">
	<span class="woocommerce-gpf-element-label">
		{label}
	</span>:
	<span class="woocommerce-gpf-element-value">
		{values}
	</span>
</div>
