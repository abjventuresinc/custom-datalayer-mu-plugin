<?php // phpcs:disable Internal.NoCodeFound ?><div id="woocommerce_gpf_options{loop_idx}" {style}>
