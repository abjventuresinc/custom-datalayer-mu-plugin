<?php // phpcs:disable Internal.NoCodeFound ?><brands>{brands}</brands>
