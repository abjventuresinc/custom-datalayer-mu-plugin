</ul>
<a href="{manage_url}" class="button button-secondary"><?php esc_html_e( 'Manage feeds', 'woocommerce_gpf' ); ?></a>
