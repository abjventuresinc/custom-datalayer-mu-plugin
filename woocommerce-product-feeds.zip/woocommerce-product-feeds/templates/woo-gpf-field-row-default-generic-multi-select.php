<?php // phpcs:disable Internal.NoCodeFound ?>
<select name="_woocommerce_gpf_data[{key}][]"
		class="woocommerce-gpf-store-default woocommerce-gpf-store-default-{raw_key}" multiple="multiple">
	{emptyoption}
	{options}
</select>
<script>
	jQuery('[name="_woocommerce_gpf_data\[{key}\]\[\]"]').selectWoo();
</script>
