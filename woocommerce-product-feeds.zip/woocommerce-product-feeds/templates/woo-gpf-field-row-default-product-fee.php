	<label for="_woocommerce_gpf_data[{key}][{subidx}][type]"><?php esc_html_e( 'Fee type:', 'woocommerce_gpf' ); ?></label><br>
	<input type="text" name="_woocommerce_gpf_data[{key}][{subidx}][type]" value="{type}"><br>
	<label for="_woocommerce_gpf_data[{key}][{subidx}][amount]"><?php esc_html_e( 'Attribute value:', 'woocommerce_gpf' ); ?></label><br>
	<textarea name="_woocommerce_gpf_data[{key}][{subidx}][amount]" cols="80" rows="3">{amount}</textarea>
	</p>
	<p>
