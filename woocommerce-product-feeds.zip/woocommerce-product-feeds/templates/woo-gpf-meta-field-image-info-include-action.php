<div class="woo-gpf-image-item-status woo-gpf-image-item-status-excluded">
	<div><?php esc_html_e( 'Excluded', 'woocommerce_gpf' ); ?></div>
	<a class="woo-gpf-image-source-include-item" data-nonce="{nonce}">
		<span class="dashicons dashicons-insert"></span> <?php echo esc_html( _x( 'Include', 'Button to include a specific image for a product in the feed', 'woocommerce_gpf' ) ); ?>
	</a>
</div>


