		<p>
			<a class="button button-secondary woocommerce-gpf-manage-images"><small><?php echo esc_html( _x( 'Manage images', 'Button to manage which images are used for items in the feed', 'woocommerce_gpf' ) ); ?></small></a>
			<a class="button button-secondary woocommerce-gpf-collapse-images" style="display:none;"><small><?php echo esc_html( _x( 'Collapse', 'Button to collapse the area in which images are used for items in the feed', 'woocommerce_gpf' ) ); ?></small></a>
		</p>
	</div>
</div>
