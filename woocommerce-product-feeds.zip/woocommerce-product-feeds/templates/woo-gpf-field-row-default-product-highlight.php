<?php // phpcs:disable Internal.NoCodeFound ?>
<input type="text" name="_woocommerce_gpf_data[{key}][{subidx}]" class="woocommerce-gpf-store-default" size="80" value="{highlight}">
</p>
<p>
