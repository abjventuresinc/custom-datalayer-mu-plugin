<?php // phpcs:disable Internal.NoCodeFound ?><brand>{brand}</brand>
