<?php //phpcs:disable woo-gpf-admin-feed-image.php ?>
<span class="woocommerce_gpf_feed_type_icon">
	<img src="{image_url}" alt="{alt_text}">
</span>
