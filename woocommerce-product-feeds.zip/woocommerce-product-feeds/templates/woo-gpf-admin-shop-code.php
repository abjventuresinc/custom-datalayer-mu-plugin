<?php
/**
 * Template for shop_code setting for Google Local Product Inventory Feed
 *
 * @package  woocommerce-gpf
 */

?>
<p>
	<label for="woocommerce_gpf_config[shop_code]"><strong><?php esc_html_e( 'Store code (for local product inventory feed):', 'woocommerce_gpf' ); ?></strong></label>
</p>
<p>
	<input type="text" class="woocommerce_gpf_field_selector" name="woocommerce_gpf_config[shop_code]" id="woocommerce_gpf_config[shop_code]" value="{shop_code}">
</p>
