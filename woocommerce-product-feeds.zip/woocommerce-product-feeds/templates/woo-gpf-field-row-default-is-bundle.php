<?php // phpcs:disable Internal.NoCodeFound ?>
<input type="checkbox" name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default" {value}>
