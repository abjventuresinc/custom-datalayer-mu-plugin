<?php // phpcs:disable Internal.NoCodeFound ?>
<tr valign="top" class="form-field new">
	{header_content}
	{data_content}
</tr>
