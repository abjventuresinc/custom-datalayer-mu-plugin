<?php // phpcs:disable Internal.NoCodeFound ?><gtins>{gtins}</gtins>
