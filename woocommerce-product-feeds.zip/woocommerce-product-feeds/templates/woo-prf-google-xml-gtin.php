<?php // phpcs:disable Internal.NoCodeFound ?><gtin>{gtin}</gtin>
