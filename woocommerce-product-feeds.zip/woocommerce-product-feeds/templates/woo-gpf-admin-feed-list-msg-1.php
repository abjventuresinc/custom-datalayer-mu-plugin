<div class="notice notice-success">
	<p><?php esc_html_e( 'Feed updated', 'woocommerce_gpf' ); ?></p>
</div>
