<?php // phpcs:disable Internal.NoCodeFound ?><product_ids>{gtins}{mpns}{skus}{brands}</product_ids>
