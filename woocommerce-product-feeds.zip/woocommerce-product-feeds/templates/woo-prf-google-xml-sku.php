<?php // phpcs:disable Internal.NoCodeFound ?><sku>{sku}</sku>
