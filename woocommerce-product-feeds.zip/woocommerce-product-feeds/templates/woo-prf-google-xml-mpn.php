<?php // phpcs:disable Internal.NoCodeFound ?><mpn>{mpn}</mpn>
