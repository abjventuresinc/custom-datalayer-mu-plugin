<?php

/**
 * Class PWBE_WooCommerce_GPF
 *
 * NOOP class.
 * See WoocommerceGpfPwBulkEdit::run()
 */
class PWBE_WooCommerce_GPF {
}
